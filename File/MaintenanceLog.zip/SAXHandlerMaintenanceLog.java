package com.bharath.xmlparsers.sax;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXHandlerMaintenanceLog extends DefaultHandler {
    private StringBuilder content = new StringBuilder();

    // Vehicle fields
    private String make, model, vehicleType, vin;
    private int year;

    // Service fields
    private String serviceDate, serviceDescription;
    private int mileage;
    private double totalCost;

    // Part fields
    private String partName;
    private double partCost;

    // Inspection fields
    private String inspectionType, result;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        content.setLength(0); // Clear previous content

        // Extract part cost attribute if available
        if (qName.equals("tns:part") && attributes.getLength() > 0) {
            partCost = Double.parseDouble(attributes.getValue("cost"));
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        content.append(ch, start, length);
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        switch (qName) {
            // Vehicle
            case "tns:make":
                make = content.toString().trim(); break;
            case "tns:model":
                model = content.toString().trim(); break;
            case "tns:year":
                year = Integer.parseInt(content.toString().trim()); break;
            case "tns:vehicleType":
                vehicleType = content.toString().trim(); break;
            case "tns:vin":
                vin = content.toString().trim(); break;
            case "tns:vehicleDetails":
                System.out.println("Vehicle Details:");
                System.out.println("Make:" + make);
                System.out.println("Model:" + model);
                System.out.println("Year:" + year);
                System.out.println("Type:" + vehicleType);
                System.out.println("VIN:" + vin);
                break;

            // Service
            case "tns:date":
                serviceDate = content.toString().trim(); break;
            case "tns:mileage":
                mileage = Integer.parseInt(content.toString().trim()); break;
            case "tns:serviceDescription":
                serviceDescription = content.toString().trim(); break;
            case "tns:part":
                partName = content.toString().trim();
                System.out.println("  Part used: " + partName + " ($" + partCost + ")");
                break;
            case "tns:totalCost":
                totalCost = Double.parseDouble(content.toString().trim()); break;
            case "tns:serviceDetails":
                System.out.println("Service Details:");
                System.out.println("Date:" + serviceDate);
                System.out.println("Mileage:" + mileage);
                System.out.println("Description:" + serviceDescription);
                System.out.println("Total Cost:$" + totalCost);
                break;

            // Inspection
            case "tns:inspectionType":
                inspectionType = content.toString().trim(); break;
            case "tns:result":
                result = content.toString().trim(); break;
            case "tns:inspectionDetails":
                System.out.println("Inspection Details:");
                System.out.println("Type:" + inspectionType);
                System.out.println("Result:" + result);
                break;
        }
    }
}