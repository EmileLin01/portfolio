package com.bharath.xmlparsers.stax;

import java.io.InputStream;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

public class STAXParserMaintenanceLog {
    public static void main(String[] args) {
        try {
            // Load XML file
            InputStream xmlStream = ClassLoader.getSystemResourceAsStream("xml/MaintenanceLog.xml");
            XMLInputFactory factory = XMLInputFactory.newInstance();
            XMLStreamReader reader = factory.createXMLStreamReader(xmlStream);

            while (reader.hasNext()) {
                int event = reader.next();

                switch (event) {
                    case XMLStreamConstants.START_ELEMENT:
                        String startTag = reader.getLocalName();
                        System.out.println("Start tag: " + startTag);

                        // Print attributes (e.g., part cost)
                        for (int i = 0; i < reader.getAttributeCount(); i++) {
                            String attrName = reader.getAttributeLocalName(i);
                            String attrValue = reader.getAttributeValue(i);
                            System.out.println("  Attribute: " + attrName + " = " + attrValue);
                        }

                        // Peek at text (CHARACTERS comes next)
                        if (reader.hasNext()) {
                            int nextEvent = reader.next();
                            if (nextEvent == XMLStreamConstants.CHARACTERS) {
                                String text = reader.getText().trim();
                                if (!text.isEmpty()) {
                                    System.out.println("  Text: " + text);
                                }
                            }
                        }
                        break;

                    case XMLStreamConstants.END_ELEMENT:
                        System.out.println("End tag: " + reader.getLocalName());
                        break;
                }
            }

            reader.close();
            xmlStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}