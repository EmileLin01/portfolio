<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:tns="http://www.example.org/MaintenanceLog"
  exclude-result-prefixes="tns">

  <xsl:output method="html" indent="yes"/>
  
  <xsl:template match="/tns:maintenanceLog">
    <html>
      <head>
        <title>Maintenance Log</title>
      </head>
      
      <body>
        <h1>Vehicle Maintenance Report</h1>

        <h2>Vehicle Details</h2>
        <p><strong>Make:</strong> <xsl:value-of select="tns:vehicleDetails/tns:make"/></p>
        <p><strong>Model:</strong> <xsl:value-of select="tns:vehicleDetails/tns:model"/></p>
        <p><strong>Year:</strong> <xsl:value-of select="tns:vehicleDetails/tns:year"/></p>
        <p><strong>Type:</strong> <xsl:value-of select="tns:vehicleDetails/tns:vehicleType"/></p>
        <p><strong>VIN:</strong> <xsl:value-of select="tns:vehicleDetails/tns:vin"/></p>

        <h2>Service Details</h2>
        <p><strong>Date:</strong> <xsl:value-of select="tns:serviceDetails/tns:date"/></p>
        <p><strong>Mileage:</strong> <xsl:value-of select="tns:serviceDetails/tns:mileage"/></p>
        <p><strong>Description:</strong> <xsl:value-of select="tns:serviceDetails/tns:serviceDescription"/></p>
        <p><strong>Parts Used:</strong></p>
        <ul>
          <xsl:for-each select="tns:serviceDetails/tns:partsUsed/tns:part">
            <li>
              <xsl:value-of select="."/> ($<xsl:value-of select="@cost"/>)
            </li>
          </xsl:for-each>
        </ul>
        <p><strong>Total Cost:</strong> $<xsl:value-of select="tns:serviceDetails/tns:totalCost"/></p>

        <h2>Inspection Details</h2>
        <p><strong>Type:</strong> <xsl:value-of select="tns:inspectionDetails/tns:inspectionType"/></p>
        <p><strong>Result:</strong> <xsl:value-of select="tns:inspectionDetails/tns:result"/></p>
        
      </body>
    </html>
 </xsl:template>
</xsl:stylesheet>