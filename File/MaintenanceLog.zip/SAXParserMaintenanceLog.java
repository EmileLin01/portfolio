package com.bharath.xmlparsers.sax;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class SAXParserMaintenanceLog {
    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {

        SAXParserFactory parserFactory = SAXParserFactory.newInstance();
        SAXParser parser = parserFactory.newSAXParser();

        SAXHandlerMaintenanceLog handler = new SAXHandlerMaintenanceLog();
        parser.parse(ClassLoader.getSystemResourceAsStream("xml/MaintenanceLog.xml"), handler);
    }
}