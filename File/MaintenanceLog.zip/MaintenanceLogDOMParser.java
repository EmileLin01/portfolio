package com.bharath.xmlparsers.dom;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MaintenanceLogDOMParser {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder documentBuilder = factory.newDocumentBuilder();
		Document document = documentBuilder.parse(ClassLoader.getSystemResourceAsStream("xml/MaintenanceLog.xml"));
		
		
		// Extract "make" as a String
		NodeList makeList = document.getElementsByTagName("tns:make");
		if (makeList.getLength() > 0) {
			String make = makeList.item(0).getTextContent();
	        System.out.println("Make: " + make);
	    } else {
	        System.out.println("No make tag found.");
	    }
		
        // Extract "mileage" as a long (numeric)
        NodeList mileageList = document.getElementsByTagName("tns:mileage");
        if (mileageList.getLength() > 0) {
            long mileage = Long.parseLong(mileageList.item(0).getTextContent());
            System.out.println("Mileage: " + mileage);
        } else {
            System.out.println("No mileage tag found.");
        }
        
        // Extract all elements in "vehicleDetails"
        String ns = "http://www.example.org/MaintenanceLog"; 

        String make = getTagValue(document, ns, "make");
        String model = getTagValue(document, ns, "model");
        int year = Integer.parseInt(getTagValue(document, ns, "year"));
        String type = getTagValue(document, ns, "vehicleType");
        String vin = getTagValue(document, ns, "vin");

        // Print the results
        System.out.println("Vehicle Details:");
        System.out.println("Make: " + make);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
        System.out.println("Type: " + type);
        System.out.println("VIN: " + vin);
        
	}
        
        // Helper method to extract text content of a tag by namespace
        private static String getTagValue(Document doc, String namespace, String tagName) {
            NodeList list = doc.getElementsByTagNameNS(namespace, tagName);
            if (list.getLength() > 0) {
                return list.item(0).getTextContent();
            }
            return "";
        }
    }
